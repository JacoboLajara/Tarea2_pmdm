package lajara.lopez.pmdm.jlltarea2;

public class CharacterData {
    private final String image;
    private final String name;

    public CharacterData(String image, String name){
        this.image = image;
        this.name= name;

    }

    public String getImage() {
        return image;
    }

    public String getName() {
        return name;
    }
}
