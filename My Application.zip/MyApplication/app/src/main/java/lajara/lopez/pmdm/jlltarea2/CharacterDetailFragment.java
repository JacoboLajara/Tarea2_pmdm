package lajara.lopez.pmdm.jlltarea2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.squareup.picasso.Picasso;

import lajara.lopez.pmdm.jlltarea2.databinding.CharacterDetailFragmentBinding;


public class CharacterDetailFragment extends Fragment {

    private CharacterDetailFragmentBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle saveInstanceState) {
        //inflar el layout para este fragmento
        binding = CharacterDetailFragmentBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle saveInstanceState) {
        super.onViewCreated(view, saveInstanceState);

        //Obtener datos del argumento que inicia este fragmento
        if (getArguments() != null) {
            String image = getArguments().getString("image");
            String name = getArguments().getString("name");
            Picasso.get()
                    .load(image)
                    .into(binding.image);
            binding.name.setText(name);
        }


    }

    @Override
    public void onStart() {
        super.onStart();

        if (getArguments() != null) {
            String name = getArguments().getString("name");
            String image = getArguments().getString("image");
            Picasso.get()
                    .load(image)
                    .into(binding.image);
            binding.name.setText(name);

        }
    }
}
